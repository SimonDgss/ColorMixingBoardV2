This is the code for the Color Mixing Board :
Channel A : Pulse Width Modulation
State machine :
 - Ifs : Current max that you put through one LED, up to 30mA, step of 1; long push reset every color
 - Freq : Frequency of the PWM, 1Hz, 10Hz and 100Hz; To get 10 Hz you have to put the switch between 2 positions
 - Red : Duty cycle of the red LED, from 0 to 100, step of 2
 - Green : Duty cycle of the green LED, from 0 to 100, step of 2
 - Blue : Duty cycle of the blue LED, from 0 to 100, step of 2

Channel B : Constant Current Drive
State machine :
 - Red : Current max for the red LED through 1 LED, up to 30mA, step of 1
 - Green : Current max for the green LED through 1 LED, up to 30mA, step of 1
 - Blue : Current max for the blue LED through 1 LED, up to 30mA, step of 1
 - Rainbow (RNBW) : Mode where color is always changing; long push to reset and get back to Red

Quick push : Change of state
Long push : Reset values

Any question ? Simon.degres@we-online.com