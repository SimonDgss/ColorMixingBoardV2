
		  case redA:
			  affichageState('r', ifsredA,DELAI,0,0);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsredA=0;
				  setlight(ifsredA, redA,CHANNELA);
				  longpressA=FALSE;
			  }
			  rotate_encA(&ifsredA,redA);
			  break;

		  case greenA:
			  affichageState('g', ifsgreenA,DELAI,0,0);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsgreenA=0;
				  setlight(ifsgreenA, greenA,CHANNELA);
				  longpressA=FALSE;
			  }
			  rotate_encA(&ifsgreenA,greenA);
			  break;

		  case blueA:

			  affichageState('b', ifsblueA,DELAI,0,0);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsblueA=0;
				  setlight(ifsblueA, blueA,CHANNELA);
				  longpressA=FALSE;
			  }
			  rotate_encA(&ifsblueA,blueA);
			  break;

            case rainbowA:
			  displayState('W', 555,DELAY,0,0);
			  frainbowA();
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsgreenA=0;ifsredA=0;ifsblueA=0;dc_redA=0;dc_greenA=0;dc_blueA=0;
				  setlight(ifsblueA, blueA,CHANNELA);setlight(ifsredA, redA,CHANNELA);setlight(ifsgreenA, greenA,CHANNELA);
				  longpressA=FALSE;
				  stateA=redA;
			  }
			  break;