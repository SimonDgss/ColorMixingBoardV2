#include "function.h"    /* Always include the header file that declares something
                     	 * in the C file that defines it. This makes sure that the
                     	 * declaration and definition are always in-sync.  Put this
                     	 * header first in foo.c to ensure the header is self-contained.
                     	 */
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"
#include <string.h>

//		 AAAAAAAAAA
//		F          B
//		F          B
//		F          B
//		F          B
//		F          B
//		 GGGGGGGGGG
//		E          C
//		E          C
//		E          C
//		E          C
//		E          C
//		 DDDDDDDDDD  DP
//

const uint8_t SevenSegmentASCII[96] = { 0x00, /* (space) */0x86, /* ! */0x22, /* " */
0x7E, /* # */0x6D, /* $ */0xD2, /* % */0x46, /* & */
0x20, /* ' */0x29, /* ( */0x0B, /* ) */0x21, /* * */0x70, /* + */0x10, /* , */
0x40, /* - */0x80, /* . */
0x52, /* / */0x3F, /* 0 */0x06, /* 1 */0x5B, /* 2 */0x4F, /* 3 */0x66, /* 4 */
0x6D, /* 5 */0x7D, /* 6 */
0x07, /* 7 */0x7F, /* 8 */0x6F, /* 9 */0x09, /* : */0x0D, /* ; */0x61, /* < */
0x48, /* = */0x43, /* > */
0xD3, /* ? */0x5F, /* @ */0x77, /* A */0x7C, /* B */0x39, /* C */0x5E, /* D */
0x79, /* E */0x71, /* F */
0x3D, /* G */0x76, /* H */0x30, /* I */0x1E, /* J */0x75, /* K */0x38, /* L */
0x15, /* M */0x37, /* N */
0x3F, /* O */0x73, /* P */0x6B, /* Q */0x33, /* R */0x6D, /* S */0x78, /* T */
0x3E, /* U */0x3E, /* V */
0x2A, /* W */0x76, /* X */0x6E, /* Y */0x5B, /* Z */0x39, /* [ */0x64, /* \ */
0x0F, /* ] */0x23, /* ^ */
0x08, /* _ */0x02, /* ` */0x5F, /* a */0x7C, /* b */0x58, /* c */0x5E, /* d */
0x7B, /* e */0x71, /* f */
0x6F, /* g */0x74, /* h */0x10, /* i */0x0C, /* j */0x75, /* k */0x30, /* l */
0x14, /* m */0x54, /* n */
0x5C, /* o */0x73, /* p */0x67, /* q */0x50, /* r */0x6D, /* s */0x78, /* t */
0x1C, /* u */0x1C, /* v */
0x14, /* w */0x76, /* x */0x6E, /* y */0x5B, /* z */0x46, /* { */0x30, /* | */
0x70, /* } */0x01, /* ~ */
0x00, /* (del) */
};

void blank_sevenseg(void)		//Turn off all segment
{
	uint16_t pinportA = SEG_A_Pin;
	uint16_t pinportC = SEG_B_Pin | SEG_C_Pin | SEG_D_Pin;
	uint16_t pinportB = SEG_F_Pin | SEG_G_Pin | SEG_DP_Pin | DIGIT1_Pin
			| DIGIT2_Pin | DIGIT3_Pin | DIGIT4_Pin | DIGIT5_Pin | DIGIT6_Pin
			| DIGIT7_Pin | DIGIT8_Pin;
	uint16_t pinportD = SEG_E_Pin;

	HAL_GPIO_WritePin(SEG_A_GPIO_Port, pinportA, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SEG_B_GPIO_Port, pinportC, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SEG_E_GPIO_Port, pinportD, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SEG_F_GPIO_Port, pinportB, GPIO_PIN_RESET);
}

void printchar(uint16_t chara, uint16_t Pin) {
	int segmA = (0x01 & (SevenSegmentASCII[chara - 32]));
	int segmB = (0x02 & (SevenSegmentASCII[chara - 32])) >> 1;
	int segmC = (0x04 & (SevenSegmentASCII[chara - 32])) >> 2;
	int segmD = (0x08 & (SevenSegmentASCII[chara - 32])) >> 3;
	int segmE = (0x10 & (SevenSegmentASCII[chara - 32])) >> 4;
	int segmF = (0x20 & (SevenSegmentASCII[chara - 32])) >> 5;
	int segmG = (0x40 & (SevenSegmentASCII[chara - 32])) >> 6;
	int segmDP = (0x80 & (SevenSegmentASCII[chara - 32])) >> 7;
	blank_sevenseg();
	HAL_GPIO_WritePin(SEG_A_GPIO_Port, SEG_A_Pin, segmA);
	HAL_GPIO_WritePin(SEG_B_GPIO_Port, SEG_B_Pin, segmB);
	HAL_GPIO_WritePin(SEG_C_GPIO_Port, SEG_C_Pin, segmC);
	HAL_GPIO_WritePin(SEG_D_GPIO_Port, SEG_D_Pin, segmD);
	HAL_GPIO_WritePin(SEG_E_GPIO_Port, SEG_E_Pin, segmE);
	HAL_GPIO_WritePin(SEG_F_GPIO_Port, SEG_F_Pin, segmF);
	HAL_GPIO_WritePin(SEG_G_GPIO_Port, SEG_G_Pin, segmG);
	HAL_GPIO_WritePin(SEG_DP_GPIO_Port, SEG_DP_Pin, segmDP);
	HAL_GPIO_WritePin(DIGIT1_GPIO_Port, Pin, GPIO_PIN_SET);
}

void printFigures(uint8_t number, uint16_t Pin, uint8_t leading_zero) {
	printchar(number + 48, Pin);

	if (!leading_zero) {
		if (number == 0) {
			HAL_GPIO_WritePin(GPIOB, Pin, GPIO_PIN_RESET);
		}
	}
}

void displayState(char letterstate, uint8_t number, uint8_t delai,
		uint8_t position, uint8_t call) {
	blank_sevenseg();
	static int j = 0;
	int digit[3];
	if (arr < 10000 && stateA == frequencyA && position == 1) {
		call = 0;
	}

	digit[0] = (number) % 10;
	digit[1] = (((number) - digit[0]) / 10) % 10;
	digit[2] = (((number) - digit[1] * 10 - digit[0]) / 100) % 10;

	if (call && j == 0)
		j = 1;
	if (call) {
		j--;

	}
	if (!call && j == 4)
		j = 0;
	switch (j) {

	case 0: {
		printchar(digit[0] + 48, DIGIT4_Pin << position * 6);
		break;
	}
	case 1: {
		printchar(digit[1] + 48, DIGIT3_Pin << position * 6);
		break;
	}
	case 2: {
		printchar(digit[2] + 48, DIGIT2_Pin << position * 6);
		break;
	}
	case 3: {
		printchar(letterstate, DIGIT1_Pin << position * 6);
		break;
	}
	}
	j++;
}

void displayDig(uint16_t position_compteur, uint8_t position, uint8_t call) {
	static int j = 0;
	int digit[4];

	if (call && j == 0)
		j = 1;
	if (call)
		j--;
	if (!call && j == 4)
		j = 0;
	switch (j) {

	case 0: {
		digit[0] = abs(position_compteur) % 10;
		digit[1] = ((abs(position_compteur) - digit[0]) / 10) % 10;
		digit[2] = ((abs(position_compteur) - digit[1] * 10 - digit[0]) / 100)
				% 10;
		digit[3] = ((abs(position_compteur) - digit[2] * 100 - digit[0]
				- digit[1] * 10) / 1000) % 10;
		printFigures(digit[0], DIGIT4_Pin << position * 6, 1);
		break;
	}
	case 1: {
		digit[0] = abs(position_compteur) % 10;
		digit[1] = ((abs(position_compteur) - digit[0]) / 10) % 10;
		digit[2] = ((abs(position_compteur) - digit[1] * 10 - digit[0]) / 100)
				% 10;
		digit[3] = ((abs(position_compteur) - digit[2] * 100 - digit[0]
				- digit[1] * 10) / 1000) % 10;
		printFigures(digit[1], DIGIT3_Pin << position * 6, 1);
		break;
	}
	case 2: {
		digit[0] = abs(position_compteur) % 10;
		digit[1] = ((abs(position_compteur) - digit[0]) / 10) % 10;
		digit[2] = ((abs(position_compteur) - digit[1] * 10 - digit[0]) / 100)
				% 10;
		digit[3] = ((abs(position_compteur) - digit[2] * 100 - digit[0]
				- digit[1] * 10) / 1000) % 10;
		printFigures(digit[2], DIGIT2_Pin << position * 6, 1);
		break;
	}
	case 3: {
		digit[0] = abs(position_compteur) % 10;
		digit[1] = ((abs(position_compteur) - digit[0]) / 10) % 10;
		digit[2] = ((abs(position_compteur) - digit[1] * 10 - digit[0]) / 100)
				% 10;
		digit[3] = ((abs(position_compteur) - digit[2] * 100 - digit[0]
				- digit[1] * 10) / 1000) % 10;
		printFigures(digit[3], DIGIT1_Pin << position * 6, 1);
		break;
	}
	}
	j++;
}

void displayChar(char *word, uint8_t delai, uint8_t position, uint8_t call) {

	blank_sevenseg();
	static int i = 0;

	if (call && i == 0)
		i = 1;
	if (call)
		i--;
	if (!call && i == 4)
		i = 0;
	switch (i) {
	case 0: {
		printchar(word[i], DIGIT1_Pin << position * 6);
	}
		break;
	case 1: {
		printchar(word[i], DIGIT2_Pin << position * 6);
	}
		break;
	case 2: {
		printchar(word[i], DIGIT3_Pin << position * 6);
	}
		break;
	case 3: {
		printchar(word[i], DIGIT4_Pin << position * 6);
	}
		break;
	}
	i++;
}

void dispfreq(uint16_t arr) {
	uint8_t call = 0;
	static int i = 0;
	switch (arr) {
	case 100: {

		if (call && i == 0)
			i = 1;
		if (call)
			i--;
		if (!call && i == 4)
			i = 0;
		switch (i) {
		case 0: {
			printchar('F', DIGIT1_Pin);
		}
			break;
		case 1: {
			printchar('1', DIGIT2_Pin);
		}
			break;
		case 2: {
			printchar('0', DIGIT3_Pin);
		}
			break;
		case 3: {
			printchar('0', DIGIT4_Pin);
		}
			break;
		}
		i++;

	}
		break;
	case 1000: {

		if (call && i == 0)
			i = 1;
		if (call)
			i--;
		if (!call && i == 4)
			i = 0;
		switch (i) {
		case 0: {
			printchar('F', DIGIT1_Pin);
		}
			break;
		case 1: {
		}
			break;
		case 2: {
			printchar('1', DIGIT3_Pin);
		}
			break;
		case 3: {
			printchar('0', DIGIT4_Pin);
		}
			break;
		}
		i++;
	}
		break;
	case 10000:
		displayState('F', 1, 0, 0, 0);
		/*if(psc==10)
		 displayState('F', 10, 0, 0, 0);
		 if(psc==100)
		 displayState('F', 1, 0, 0, 0);*/
		break;
	}

}

void frainbowB() {
	static uint8_t color = white;
	static uint16_t pulser = 1000;
	static uint16_t pulseg = 1000;
	static uint16_t pulseb = 1000;
	switch (color) {
	case white:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulseg--;
		if (pulseg == 0)
			color = purple;
		break;
	case purple:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulser--;
		if (!pulser)
			color = blue;
		break;
	case blue:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulseg++;
		if (pulseg == 1000)
			color = cyan;
		break;
	case cyan:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulseb--;
		if (!pulseb)
			color = green;
		break;
	case green:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulser++;
		if (pulser == 1000)
			color = yellow;
		break;
	case yellow:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulseg--;
		if (!pulseg)
			color = red;
		break;
	case red:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulseb++;
		if (pulseb == 1000)
			color = purple2;
		break;
	case purple2:
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb / 10);
		pulseg++;
		if (pulseg == 1000)
			color = white;
		break;
	}
}

void frainbowA() {
	static uint8_t color = white;
	static uint16_t pulser = 1000;
	static uint16_t pulseg = 1000;
	static uint16_t pulseb = 1000;
	switch (color) {
	case white:
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb / 10);
		pulseg--;
		if (pulseg == 0)
			color = purple;
		break;
	case purple:
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb / 10);
		pulser--;
		if (!pulser)
			color = blue;
		break;
	case blue:
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb / 10);
		pulseg++;
		if (pulseg == 1000)
			color = cyan;
		break;
	case cyan:
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb / 10);
		pulseb--;
		if (!pulseb)
			color = green;
		break;
	case green:
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb / 10);
		pulser++;
		if (pulser == 1000)
			color = yellow;
		break;
	case yellow:
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb / 10);
		pulseg--;
		if (!pulseg)
			color = red;
		break;
	case red:
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg / 10);
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb / 10);
		pulseg++;
		pulseb++;
		if (pulseg == 1000)
			color = white;
		break;
	}
}

void is_push(uint8_t *shortpress, uint8_t *longpress, uint8_t *state,
		uint8_t channel) {
	uint8_t SW1 = HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin);
	uint8_t flag = 0;
	uint16_t counter = 0;
	void sw1() {
		if (channel == FALSE) {
			SW1 = HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin);
		} else {
			SW1 = HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin);
		}
	}
	sw1();
	if (SW1 == FALSE && *longpress == FALSE && *shortpress == FALSE) {
		flag = TRUE;
		while (SW1 == FALSE && flag == TRUE) {
			if (flag1ms) {
				counter++;
				flag1ms = 0;
			}
			if (counter > 0) {
				*shortpress = TRUE;
				*longpress = FALSE;
				if (channel == FALSE) {
					displayChar("shrt", DELAY, 0, 0);
				} else {
					displayChar("shrt", DELAY, 1, 0);
				}

				if (counter > 1000 - 1) {
					*shortpress = FALSE;
					*longpress = TRUE;
					flag = 0;
				}
			}
			sw1();

		}
		counter = 0;
	}
	sw1();
	if (*shortpress == TRUE && SW1 == TRUE) {
		*shortpress = FALSE;
		compt = 0;
		if (stateB == 3) {
			*longpress = TRUE;
		}
		else
			(*state) += 1;
		if (stateA == 5) {
			stateA = 0;
		}

	}

}

void getADC(uint16_t *maxA, uint16_t *maxB) {
	HAL_ADC_Start(&hadc1);					//ADC in4 get DB plugged channel A
	HAL_ADC_PollForConversion(&hadc1, 10000);
	*maxA = HAL_ADC_GetValue(&hadc1);

	HAL_ADC_Start(&hadc1);					//ADC in5 get DB plugged channel B
	HAL_ADC_PollForConversion(&hadc1, 10000);
	*maxB = HAL_ADC_GetValue(&hadc1);
}

void convert_dig_to_analog(uint16_t *maxA, uint16_t *maxB,
		uint8_t *daugtherboardA, uint8_t *daugtherboardB) {
	uint8_t count = 0;
	if (*maxA < 2450) {
		*daugtherboardA = 3;
		TURN_ON_D1_BLUE
		;
	} else if (*maxA > 3500) {
		*daugtherboardA = 1;
		TURN_OFF_D1_BLUE
		;
	} else {
		*daugtherboardA = 4;
		TURN_ON_D1_BLUE
		;
	}
	if (*maxB < 2450) {
		*daugtherboardB = 3;
	} else if (*maxB > 3500) {
		*daugtherboardB = 1;
		TURN_OFF_D1_RED
		;
	} else {
		*daugtherboardB = 4;
	}
}

void setlight(uint16_t percent, uint8_t channel_timer, uint8_t channel) {
	if (channel == CHANNELA) {
		__HAL_TIM_SET_COMPARE(&htim2, (channel_timer - 1) * 4, percent);
	} else {
		__HAL_TIM_SET_COMPARE(&htim3, (channel_timer) * 4, percent);
	}

}

void rotate_encA(uint16_t *alphaa, uint8_t channel_timer, uint8_t clockwise) {
	static uint16_t lastState;
	static uint8_t variable = 0;

	if (channel_timer == ROTATE_FREQ) {
		if (HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin) != lastState) {
			if (lastState != HAL_GPIO_ReadPin(ROT_B_2_GPIO_Port, ROT_B_2_Pin)) {
				if (clockwise) {
					if (variable <= 0) {
						variable = 0;
					} else {
						variable -= INCREMENT;
					}
				} else {
					if (variable >= 4) {
						variable = 4;

					} else {
						variable += INCREMENT;
					}
				}
			} else {
				if (!clockwise) {
					if (variable <= 0) {
						variable = 0;
					} else {
						variable -= INCREMENT;
					}
				} else {
					if (variable >= 4) {
						variable = 4;
					} else {
						variable += INCREMENT;
					}
				}
			}
		}
		lastState = HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin);

		if (variable == 0)
			*alphaa = 100;
		else if (variable == 2)
			*alphaa = 1000;
		else if (variable == 4)
			*alphaa = 10000;
	}

	else if (channel_timer == ROTATE_IFS) {
		if (HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin) != lastState) {
			if (lastState != HAL_GPIO_ReadPin(ROT_B_2_GPIO_Port, ROT_B_2_Pin)) {
				if (clockwise) {
					if (*alphaa <= 0) {
						*alphaa = 0;
					} else {
						*alphaa -= INCREMENT;
					}
				} else {
					if (*alphaa >= 60) {
						*alphaa = 60;

					} else {
						*alphaa += INCREMENT;
					}
				}
			} else {
				if (!clockwise) {
					if (*alphaa <= 0) {
						*alphaa = 0;
					} else {
						*alphaa -= INCREMENT;
					}
				} else {
					if (*alphaa >= 60) {
						*alphaa = 60;
					} else {
						*alphaa += INCREMENT;
					}
				}
			}
		}
		lastState = HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin);
	} else {
		if (HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin) != lastState) {
			if (lastState != HAL_GPIO_ReadPin(ROT_B_2_GPIO_Port, ROT_B_2_Pin)) {
				if (clockwise) {
					if (*alphaa <= 0) {
						*alphaa = 0;
					} else {
						*alphaa -= INCREMENT;
					}
				} else {
					if (*alphaa >= 200) {
						*alphaa = 200;

					} else {
						*alphaa += INCREMENT;
					}
				}
			} else {
				if (!clockwise) {
					if (*alphaa <= 0) {
						*alphaa = 0;
					} else {
						*alphaa -= INCREMENT;
					}
				} else {
					if (*alphaa >= 200) {
						*alphaa = 200;
					} else {
						*alphaa += INCREMENT;
					}
				}
			}
		}
		lastState = HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin);
	}
}

void rotate_encB(uint16_t *alphaa, uint8_t channel_timer) {
	static uint16_t lastState;
	if (HAL_GPIO_ReadPin(ROT_A_1_GPIO_Port, ROT_A_1_Pin) != lastState) {
		if (lastState != HAL_GPIO_ReadPin(ROT_A_1_GPIO_Port, ROT_B_1_Pin)) {
			if (CLOCKWISE) {
				if (*alphaa <= 0) {
					*alphaa = 0;
				} else {
					*alphaa = *alphaa - INCREMENT;
				}
			} else {
				if (*alphaa >= 60) {
					*alphaa = 60;

				} else {
					*alphaa = *alphaa + INCREMENT;
				}
			}
		} else {
			if (!CLOCKWISE) {
				if (*alphaa <= 0) {
					*alphaa = 0;
				} else {
					*alphaa = *alphaa - INCREMENT;
				}
			} else {
				if (*alphaa >= 60) {
					*alphaa = 60;
				} else {
					*alphaa = *alphaa + INCREMENT;
				}
			}
		}
		setlight(*alphaa / 2 * 58 / 100 * daugtherboardB, channel_timer,
				CHANNELB);
	}
	lastState = HAL_GPIO_ReadPin(ROT_A_1_GPIO_Port, ROT_A_1_Pin);

}

