#include "function.h"    /* Always include the header file that declares something
                     	 * in the C file that defines it. This makes sure that the
                     	 * declaration and definition are always in-sync.  Put this
                     	 * header first in foo.c to ensure the header is self-contained.
                     	 */
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"
#include <string.h>


//		 AAAAAAAAAA
//		F          B
//		F          B
//		F          B
//		F          B
//		F          B
//		 GGGGGGGGGG
//		E          C
//		E          C
//		E          C
//		E          C
//		E          C
//		 DDDDDDDDDD  DP
//

const uint8_t SevenSegmentASCII[96] = {0x00, /* (space) */0x86, /* ! */0x22, /* " */0x7E, /* # */0x6D, /* $ */	0xD2, /* % */	0x46, /* & */
		0x20, /* ' */	0x29, /* ( */	0x0B, /* ) */	0x21, /* * */	0x70, /* + */	0x10, /* , */	0x40, /* - */	0x80, /* . */
		0x52, /* / */	0x3F, /* 0 */	0x06, /* 1 */	0x5B, /* 2 */	0x4F, /* 3 */	0x66, /* 4 */	0x6D, /* 5 */	0x7D, /* 6 */
		0x07, /* 7 */	0x7F, /* 8 */	0x6F, /* 9 */	0x09, /* : */	0x0D, /* ; */	0x61, /* < */	0x48, /* = */	0x43, /* > */
		0xD3, /* ? */	0x5F, /* @ */	0x77, /* A */	0x7C, /* B */	0x39, /* C */	0x5E, /* D */	0x79, /* E */	0x71, /* F */
		0x3D, /* G */	0x76, /* H */	0x30, /* I */	0x1E, /* J */	0x75, /* K */	0x38, /* L */	0x15, /* M */	0x37, /* N */
		0x3F, /* O */	0x73, /* P */	0x6B, /* Q */	0x33, /* R */	0x6D, /* S */	0x78, /* T */	0x3E, /* U */	0x3E, /* V */
		0x2A, /* W */	0x76, /* X */	0x6E, /* Y */	0x5B, /* Z */	0x39, /* [ */	0x64, /* \ */	0x0F, /* ] */	0x23, /* ^ */
		0x08, /* _ */	0x02, /* ` */	0x5F, /* a */	0x7C, /* b */	0x58, /* c */	0x5E, /* d */	0x7B, /* e */	0x71, /* f */
		0x6F, /* g */	0x74, /* h */	0x10, /* i */	0x0C, /* j */	0x75, /* k */	0x30, /* l */	0x14, /* m */	0x54, /* n */
		0x5C, /* o */	0x73, /* p */	0x67, /* q */	0x50, /* r */	0x6D, /* s */	0x78, /* t */	0x1C, /* u */	0x1C, /* v */
		0x14, /* w */	0x76, /* x */	0x6E, /* y */	0x5B, /* z */	0x46, /* { */	0x30, /* | */	0x70, /* } */	0x01, /* ~ */
		0x00, /* (del) */
};

void blank_sevenseg(void)		//Turn off all segment
{
	uint16_t pinportA = SEG_A_Pin;
	uint16_t pinportC = SEG_B_Pin|SEG_C_Pin|SEG_D_Pin;
	uint16_t pinportB = SEG_F_Pin|SEG_G_Pin|SEG_DP_Pin|DIGIT1_Pin|DIGIT2_Pin|DIGIT3_Pin|DIGIT4_Pin|DIGIT5_Pin|DIGIT6_Pin|DIGIT7_Pin|DIGIT8_Pin;
	uint16_t pinportD = SEG_E_Pin;

	HAL_GPIO_WritePin(SEG_A_GPIO_Port, pinportA, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SEG_B_GPIO_Port,pinportC , GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SEG_E_GPIO_Port, pinportD, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SEG_F_GPIO_Port,pinportB , GPIO_PIN_RESET);
}

void printchar(int chara,uint16_t Pin)
{
	int segmA =(0x01&(SevenSegmentASCII[chara-32]));
	int segmB =(0x02&(SevenSegmentASCII[chara-32]))>>1;
	int segmC =(0x04&(SevenSegmentASCII[chara-32]))>>2;
	int segmD =(0x08&(SevenSegmentASCII[chara-32]))>>3;
	int segmE =(0x10&(SevenSegmentASCII[chara-32]))>>4;
	int segmF =(0x20&(SevenSegmentASCII[chara-32]))>>5;
	int segmG =(0x40&(SevenSegmentASCII[chara-32]))>>6;
	int segmDP =(0x80&(SevenSegmentASCII[chara-32]))>>7;
	blank_sevenseg();
	HAL_GPIO_WritePin(SEG_A_GPIO_Port, SEG_A_Pin, segmA);
	HAL_GPIO_WritePin(SEG_B_GPIO_Port, SEG_B_Pin, segmB);
	HAL_GPIO_WritePin(SEG_C_GPIO_Port, SEG_C_Pin, segmC);
	HAL_GPIO_WritePin(SEG_D_GPIO_Port, SEG_D_Pin, segmD);
	HAL_GPIO_WritePin(SEG_E_GPIO_Port, SEG_E_Pin, segmE);
	HAL_GPIO_WritePin(SEG_F_GPIO_Port, SEG_F_Pin, segmF);
	HAL_GPIO_WritePin(SEG_G_GPIO_Port, SEG_G_Pin, segmG);
	HAL_GPIO_WritePin(SEG_DP_GPIO_Port, SEG_DP_Pin, segmDP);
	HAL_GPIO_WritePin(DIGIT1_GPIO_Port, Pin, GPIO_PIN_SET);
}

void printFigures(uint16_t number,uint16_t Pin, int leading_zero)
{
	printchar(number+48,Pin);

	if(!leading_zero)
	{
		if(number==0)
		{
			HAL_GPIO_WritePin(GPIOB, Pin, GPIO_PIN_RESET);
		}
	}
}

void affichageState(char letterstate, int number,int delai,int position,int appel)
{
	blank_sevenseg();
	static int j=0;
	int digit[3];

	if(appel&&j==0)
		j=1;
	if(appel)
		j--;
	if(!appel&&j==3)
		j=0;
	printchar(letterstate, DIGIT1_Pin<<position*6);
	switch (j)
	{

		case 0:
		{
			printFigures(digit[0], DIGIT4_Pin<<position*6,1);
			break;
		}
		case 1:
		{
			digit[0]=(number)%10;
			digit[1]=(((number)-digit[0])/10)%10;
			printFigures(digit[1], DIGIT3_Pin<<position*6,1);
			break;
		}
		case 2:
		{
			digit[0]=(number)%10;
			digit[1]=(((number)-digit[0])/10)%10;
			digit[2]=(((number)-digit[1]*10-digit[0])/100)%10;
			printFigures(digit[2], DIGIT2_Pin<<position*6, 1);
			break;
		}
	}
	j++;
}

void affichageDig(int position_compteur,int position,int appel)
{
	blank_sevenseg();
	static int j=0;
	int digit[4];

	if(appel&&j==0)
		j=1;
	if(appel)
		j--;
	if(!appel&&j==4)
		j=0;
	switch (j){

		case 0:
		{
			digit[0]=abs(position_compteur)%10;
			digit[1]=((abs(position_compteur)-digit[0])/10)%10;
			digit[2]=((abs(position_compteur)-digit[1]*10-digit[0])/100)%10;
			digit[3]=((abs(position_compteur)-digit[2]*100-digit[0]-digit[1]*10)/1000)%10;
			printFigures(digit[0], DIGIT4_Pin<<position*6,1);
			break;
		}
		case 1:
		{
			digit[0]=abs(position_compteur)%10;
			digit[1]=((abs(position_compteur)-digit[0])/10)%10;
			digit[2]=((abs(position_compteur)-digit[1]*10-digit[0])/100)%10;
			digit[3]=((abs(position_compteur)-digit[2]*100-digit[0]-digit[1]*10)/1000)%10;
			printFigures(digit[1], DIGIT3_Pin<<position*6,1);
			break;
		}
		case 2:
		{
			digit[0]=abs(position_compteur)%10;
			digit[1]=((abs(position_compteur)-digit[0])/10)%10;
			digit[2]=((abs(position_compteur)-digit[1]*10-digit[0])/100)%10;
			digit[3]=((abs(position_compteur)-digit[2]*100-digit[0]-digit[1]*10)/1000)%10;
			printFigures(digit[2], DIGIT2_Pin<<position*6, 1);
			break;
		}
		case 3:
		{
			digit[0]=abs(position_compteur)%10;
			digit[1]=((abs(position_compteur)-digit[0])/10)%10;
			digit[2]=((abs(position_compteur)-digit[1]*10-digit[0])/100)%10;
			digit[3]=((abs(position_compteur)-digit[2]*100-digit[0]-digit[1]*10)/1000)%10;
			printFigures(digit[3], DIGIT1_Pin<<position*6, 1);
			break;
		}
	}
	j++;
}

void affichageChar(char * word,int delai, int position, int appel)
{
	static int i=0;
	int pos=position*6;
	if(appel&&i==0)
		i=1;
	if(appel)
		i--;
	if(!appel&&i==4)
		i=0;
	switch (i){
	case 0:
	{
		printchar(word[i],DIGIT1_Pin<<pos);
		HAL_Delay(delai);
	}
	break;
	case 1:
	{
		printchar(word[i],DIGIT2_Pin<<pos);
		HAL_Delay(delai);
	}
	break;
	case 2:
	{
		printchar(word[i],DIGIT3_Pin<<pos);
		HAL_Delay(delai);

	}
	break;
	case 3:
	{
		printchar(word[i],DIGIT4_Pin<<pos);
		HAL_Delay(delai);
	}
	break;
	}
	i++;
}

void frainbowB()
{
	static uint8_t couleur=blanc;
	static uint16_t pulser=1000; static uint16_t pulseg=1000;static uint16_t pulseb=1000;
	HAL_GPIO_WritePin(DIAL_B_GPIO_Port, DIAL_B_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(DIAL_G_GPIO_Port, DIAL_G_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(DIAL_R_GPIO_Port, DIAL_R_Pin, GPIO_PIN_SET);
	switch(couleur)
	{
		case blanc:
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb/10);
			pulseg--;
			if(pulseg==0)
				couleur=violet;
			break;
		case violet:
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb/10);
			pulser--;
			if(!pulser)
				couleur=bleu;
			break;
		case bleu:
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb/10);
			pulseg++;
			if(pulseg==1000)
				couleur=cyan;
			break;
		case cyan:
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb/10);
			pulseb--;
			if(!pulseb)
				couleur=vert;
			break;
		case vert:
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb/10);
			pulser++;
			if(pulser==1000)
				couleur=jaune;
			break;
		case jaune:
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb/10);
			pulseg--;
			if(!pulseg)
				couleur=rouge;
			break;
		case rouge:
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulseb/10);
			pulseg++;
			pulseb++;
			if(pulseg==1000)
				couleur=blanc;
			break;
	}
}

void frainbowA()
{
	static uint8_t couleur=blanc;
	static uint16_t pulser=1000; static uint16_t pulseg=1000;static uint16_t pulseb=1000;
	switch(couleur)
	{
		case blanc:
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb/10);
			pulseg--;
			if(pulseg==0)
				couleur=violet;
			break;
		case violet:
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb/10);
			pulser--;
			if(!pulser)
				couleur=bleu;
			break;
		case bleu:
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb/10);
			pulseg++;
			if(pulseg==1000)
				couleur=cyan;
			break;
		case cyan:
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb/10);
			pulseb--;
			if(!pulseb)
				couleur=vert;
			break;
		case vert:
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb/10);
			pulser++;
			if(pulser==1000)
				couleur=jaune;
			break;
		case jaune:
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb/10);
			pulseg--;
			if(!pulseg)
				couleur=rouge;
			break;
		case rouge:
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulser/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, pulseg/10);
			__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, pulseb/10);
			pulseg++;
			pulseb++;
			if(pulseg==1000)
				couleur=blanc;
			break;
	}
}

void is_push(uint8_t *shortpress,uint8_t *longpress, uint8_t *state, uint8_t channel)
{
	uint8_t SW1= HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin);
	uint8_t flag=0;
	uint16_t counter=0;
	void sw1()
	{
		if(channel==FALSE)
		{
			SW1=HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin);
		}
		else
		{
			SW1=HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin);
		}
	}
	sw1();
	if(SW1==FALSE && *longpress==FALSE && *shortpress==FALSE)
	{
		flag=TRUE;
		while(SW1==FALSE && flag==TRUE)
		{
			if(flag10ms)
			{
				counter++;
				flag10ms=0;
			}
			if(counter>0)
			{
				*shortpress=TRUE;
				*longpress=FALSE;
				if(channel==FALSE)
				{
					affichageChar("shor", DELAI, 0, 0);
				}
				else
				{
					affichageChar("shor", DELAI, 1, 0);
				}

				if(counter>1000-1)
				{
					*shortpress=FALSE;
					*longpress=TRUE;
					flag=0;
				}
			}
			sw1();

		}
		counter=0;
	}
	sw1();
	if(*shortpress==TRUE && SW1==TRUE)
	{
	  *shortpress=FALSE;
	  compt=0;
	  (*state)+=1;
	  if(stateA==9)
	  {
		  stateA=0;
	  }
	  if(stateB==4)
	  {
		  stateB=0;
	  }
	}

}
/*
void getADC(uint16_t *current_sense, uint16_t *voltage, uint16_t *temp_meas, uint16_t *current_meas)
{
	HAL_ADC_Start(&hadc1);									//ADC in0 get current value
	HAL_ADC_PollForConversion(&hadc1, 10000);
	*current_sense = HAL_ADC_GetValue(&hadc1);

	HAL_ADC_Start(&hadc1);									//ADC in1 get voltage value
	HAL_ADC_PollForConversion(&hadc1, 10000);
	*voltage = HAL_ADC_GetValue(&hadc1);

	HAL_ADC_Start(&hadc1);									//ADC in2 get temperature value
	HAL_ADC_PollForConversion(&hadc1, 10000);
	*temp_meas = HAL_ADC_GetValue(&hadc1);

	HAL_ADC_Start(&hadc1);									//ADC in3 get second current value
	HAL_ADC_PollForConversion(&hadc1, 10000);
	*current_meas = HAL_ADC_GetValue(&hadc1);
}

void convert_dig_to_analog(uint16_t voltage,uint16_t current_sense,float *power,uint16_t *temp_meas, int16_t *temperature,double *voltage_disp,double *current_disp)
{

}
*/

void setlight(uint16_t percent,uint8_t channel_timer, uint8_t channel)
{
	if(channel==FALSE)
	{
		__HAL_TIM_SET_COMPARE(&htim2, (channel_timer+1)*4, percent);
	}
	else
	{
		__HAL_TIM_SET_COMPARE(&htim3, (channel_timer)*4, percent);
	}

}

void rotate_encA(uint16_t *alphaa,uint8_t channel_timer)
{
	static uint16_t lastState;
	if(HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin)!=lastState)
	{
		  if(lastState!=HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_B_2_Pin))
		  {
			  if(CLOCKWISE)
			  {
				  if (*alphaa<=0)
				  {
					  *alphaa=0;
				  }
				  else
				  {
					  *alphaa-=5;
				  }
			  }
			  else
			  {
				  if (*alphaa>=100)
				  {
					  *alphaa=100;

				  }
				  else
				  {
					  *alphaa+=5;
				  }
			  }
		  }
		  else
		  {
			  if(!CLOCKWISE)
			  {
				  if (*alphaa<=0)
				  {
					  *alphaa=0;
				  }
				  else
				  {
					  *alphaa-=5;
				  }
			  }
			  else
			  {
				  if (*alphaa>=100)
				  {
					  *alphaa=100;
				  }
				  else
				  {
					  *alphaa+=5;
				  }
			  }
		  }
		  if(channel_timer==20)
		  {
			  if(*alphaa==0)
			  {
				  TIM4->ARR=1;
			  }
			  else
			  {
				  TIM4->ARR=(TIM4->ARR)/(*alphaa);
			  }
		  }
		  if(channel_timer==21)
		  {

		  }
		  else
		  {
			  setlight(*alphaa,channel_timer,CHANNELA);
		  }
	  }
	  lastState=HAL_GPIO_ReadPin(ROT_A_2_GPIO_Port, ROT_A_2_Pin);
}

void rotate_encB(uint16_t *alphaa,uint8_t channel_timer)
{
	static uint16_t lastState;
	if(HAL_GPIO_ReadPin(ROT_A_1_GPIO_Port,ROT_A_1_Pin)!=lastState)
	{
		  if(lastState!=HAL_GPIO_ReadPin(ROT_A_1_GPIO_Port, ROT_B_1_Pin))
		  {
			  if(CLOCKWISE)
			  {
				  if (*alphaa<=0)
				  {
					  *alphaa=0;
				  }
				  else
				  {
					  *alphaa-=5;
				  }
			  }
			  else
			  {
				  if (*alphaa>=100)
				  {
					  *alphaa=100;

				  }
				  else
				  {
					  *alphaa+=5;
				  }
			  }
		  }
		  else
		  {
			  if(!CLOCKWISE)
			  {
				  if (*alphaa<=0)
				  {
					  *alphaa=0;
				  }
				  else
				  {
					  *alphaa-=5;
				  }
			  }
			  else
			  {
				  if (*alphaa>=100)
				  {
					  *alphaa=100;
				  }
				  else
				  {
					  *alphaa+=5;
				  }
			  }
		  }
		  setlight(*alphaa,channel_timer,CHANNELB);
	  }
	  lastState=HAL_GPIO_ReadPin(ROT_A_1_GPIO_Port, ROT_A_1_Pin);
}

