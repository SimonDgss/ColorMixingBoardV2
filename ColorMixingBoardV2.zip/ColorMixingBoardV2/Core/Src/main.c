/* USER CODE BEGIN Header */
#include "function.h"

/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define TURN_ON_PWM_GREEN HAL_GPIO_WritePin(GPIOC, PC4_Pin, GPIO_PIN_SET);	//Define to give the right pin the right name
#define TURN_ON_PWM_BLUE HAL_GPIO_WritePin(GPIOC, PC5_Pin, GPIO_PIN_SET);
#define TURN_ON_PWM_RED HAL_GPIO_WritePin(GPIOC, PC3_Pin, GPIO_PIN_SET);

#define TURN_OFF_PWM_GREEN HAL_GPIO_WritePin(GPIOC, PC4_Pin, GPIO_PIN_RESET);
#define TURN_OFF_PWM_BLUE HAL_GPIO_WritePin(GPIOC, PC5_Pin, GPIO_PIN_RESET);
#define TURN_OFF_PWM_RED HAL_GPIO_WritePin(GPIOC, PC3_Pin, GPIO_PIN_RESET);

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint8_t flag1ms = 0;		//Declaration of useful global variables
uint8_t stateA = maxifsA;
uint8_t stateB = redB;
uint16_t compt = 0;
uint16_t dc_redA = 0;
uint16_t dc_greenA = 0;
uint16_t dc_blueA = 0;
uint16_t max_ifsA = 0;
uint16_t psc = 1;
uint16_t arr = 100;
uint8_t daugtherboardA = 0;
uint8_t daugtherboardB = 0;
uint8_t dc_d1_red = 0;
uint8_t dc_d1_blue = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
	/* USER CODE BEGIN 1 */

	__HAL_RCC_AFIO_CLK_ENABLE();// REMAP the pin that can be used for SWD otherwise voltage drops (should be done by cubemx but seems there is an error)
	__HAL_AFIO_REMAP_SWJ_NOJTAG();
	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */
	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */
	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_ADC1_Init();
	MX_TIM2_Init();
	MX_TIM3_Init();
	MX_TIM4_Init();
	/* USER CODE BEGIN 2 */
	HAL_TIM_Base_Start_IT(&htim4);				//Start timer for interruption

	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);	//Start all the PWM for the LEDs
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);

	uint16_t current_redB = 0;			//Declaration of useful local variables
	uint16_t current_greenB = 0;
	uint16_t current_blueB = 0;

	//uint16_t ifsredA=0;uint16_t ifsgreenA=0;uint16_t ifsblueA=0;

	uint16_t maxA = 0;
	uint16_t maxB = 0;

	uint8_t shortpressA = FALSE;
	uint8_t longpressA = FALSE;

	uint8_t shortpressB = FALSE;
	uint8_t longpressB = FALSE;
	max_ifsA = 0;
	dc_greenA = 100;
	dc_blueA = 100;
	dc_redA = 100;

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {
		if (flag1ms) {	//Synchronize each while loop for a durability of 1ms

			getADC(&maxA, &maxB);
			convert_dig_to_analog(&maxA, &maxB, &daugtherboardA,
					&daugtherboardB);
			if (daugtherboardA > 1) {
				dc_d1_blue = 50;
			} else {
				dc_d1_blue = 0;
			}
			if (daugtherboardB > 1) {
				dc_d1_red = 25;
			} else {
				dc_d1_red = 0;
			}

			/*********************************************************************Channel A*********************************************************************/
			switch (stateA) {//State machine Channel A for the pulse drive LEDs

			case maxifsA:				//Set the max current pulsed in the leds
				if (compt < TIME_STATE) {
					compt++;
					displayChar("IFS ", DELAY, 0, 0);
				} else {
					displayState('I', max_ifsA / 2, DELAY, 0, 0);

				}
				if (longpressA
						&& HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)
								== TRUE) {
					max_ifsA = 0;
					setlight(max_ifsA, dcredA, CHANNELA);
					setlight(max_ifsA, dcgreenA, CHANNELA);
					setlight(max_ifsA, dcblueA, CHANNELA);
					dc_greenA = 100;
					dc_blueA = 100;
					dc_redA = 100;
					longpressA = FALSE;

				}
				rotate_encA(&max_ifsA, ROTATE_IFS, CLOCKWISE);
				setlight(max_ifsA / 2 * 31 / 100 * daugtherboardA + 7, dcgreenA,
						CHANNELA);
				setlight(max_ifsA / 2 * 31 / 100 * daugtherboardA + 7, dcredA,
						CHANNELA);
				setlight(max_ifsA / 2 * 31 / 100 * daugtherboardA + 7, dcblueA,
						CHANNELA);
				break;

			case frequencyA:			//Change the frequency from 100Hz to 1Hz
				if (compt < TIME_STATE) {
					compt++;
					displayChar("FREQ", DELAY, 0, 0);
				} else
					dispfreq(arr);
				if (longpressA == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)
								== TRUE) {
					arr = 100;
					longpressA = FALSE;
				}
				rotate_encA(&arr, ROTATE_FREQ, !CLOCKWISE);

				break;

			case dcredA:				//Change the duty_cycle of the red color
				if (compt < TIME_STATE) {
					compt++;
					displayChar("RED ", DELAY, 0, 0);
				} else
					displayState('R', (100 - dc_redA), DELAY, 0, 0);
				if (longpressA == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)
								== TRUE) {
					dc_redA = 100;
					setlight(0, dc_redA, CHANNELA);
					longpressA = FALSE;
				}
				rotate_encA(&dc_redA, dcredA, !CLOCKWISE);
				break;

			case dcgreenA:			//Change the duty_cycle of the green color
				if (compt < TIME_STATE) {
					compt++;
					displayChar("GREE", DELAY, 0, 0);
				} else
					displayState('G', (100 - dc_greenA), DELAY, 0, 0);
				if (longpressA == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)
								== TRUE) {
					dc_greenA = 100;
					setlight(0, dc_greenA, CHANNELA);
					longpressA = FALSE;
				}
				rotate_encA(&dc_greenA, dcgreenA, !CLOCKWISE);
				break;

			case dcblueA:			//Change the duty_cycle of the blue color
				if (compt < TIME_STATE) {
					compt++;
					displayChar("BLUE", DELAY, 0, 0);
				} else
					displayState('B', (100 - dc_blueA), DELAY, 0, 0);
				if (longpressA == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)
								== TRUE) {
					dc_blueA = 100;
					setlight(0, dcblueA, CHANNELA);
					longpressA = FALSE;
				}
				rotate_encA(&dc_blueA, dcblueA, !CLOCKWISE);
				break;
			}
			is_push(&shortpressA, &longpressA, &stateA, CHANNELA);

			/*********************************************************************Channel B*********************************************************************/

			switch (stateB) {//State machine Channel b for the constant current drive LEDs
			case redB://Change the duty_cycle of the red color (then filter so the voltage become constant)
				displayDig(daugtherboardB, 1, 1);
				if (compt < TIME_STATE) {
					compt++;
					displayChar("RED ", DELAY, 1, 1);
				} else
					displayState('R', current_redB / 2, DELAY, 1, 1);

				if (longpressB == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)
								== TRUE) {
					current_redB = 0;
					setlight(current_redB, redB, CHANNELB);
					longpressB = FALSE;
				}
				rotate_encB(&current_redB, redB);
				break;

			case greenB:			//Change the duty_cycle of the green color
				if (compt < TIME_STATE) {
					compt++;
					displayChar("GREE", DELAY, 1, 1);
				} else
					displayState('G', current_greenB / 2, DELAY, 1, 1);
				if (longpressB == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)
								== TRUE) {
					current_greenB = 0;
					setlight(current_greenB, greenB, CHANNELB);
					longpressB = FALSE;
				}
				rotate_encB(&current_greenB, greenB);
				break;

			case blueB:				//Change the duty_cycle of the blue color
				if (compt < TIME_STATE) {
					compt++;
					displayChar("BLUE", DELAY, 1, 1);
				} else
					displayState('b', current_blueB / 2, DELAY, 1, 1);
				if (longpressB == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)
								== TRUE) {
					current_blueB = 0;
					setlight(current_blueB, blueB, CHANNELB);
					longpressB = FALSE;
				}
				rotate_encB(&current_blueB, blueB);
				break;

			case rainbowB://Mode rainbow : change the percentage of each color in order to create a variation in different colors
				if (compt < TIME_STATE) {
					compt++;
					displayChar("RNBW", DELAY, 1, 1);
				} else
					displayChar("RNBW", DELAY, 1, 0);
				frainbowB();
				if (longpressB == TRUE || shortpressB == TRUE
						&& HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)
								== TRUE) {
					current_blueB = 0;
					current_redB = 0;
					current_greenB = 0;
					setlight(current_blueB, blueB, CHANNELB);
					setlight(current_redB, redB, CHANNELB);
					setlight(current_greenB, greenB, CHANNELB);
					longpressB = FALSE;
					stateB = redB;
				}
				break;
			}
			is_push(&shortpressB, &longpressB, &stateB, CHANNELB);//Function is_push : check if the encoder is pushed to change state (quick push) or to reset variables (long push)

			flag1ms = 0;
		}
	}
	/* USER CODE END WHILE */

	/* USER CODE BEGIN 3 */
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInit = { 0 };

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL4;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK) {
		Error_Handler();
	}
	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
	PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV4;
	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK) {
		Error_Handler();
	}
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	static uint16_t sawtooth = 0;
	if (sawtooth % 10 == 0) {
		flag1ms = 1;			//Synchronization flag, get high every 1ms
	}

	if ((sawtooth) == (dc_redA * arr / 100)) {
		TURN_OFF_PWM_RED
		;
	}
	if ((sawtooth) == (dc_greenA * arr / 100)) {
		TURN_OFF_PWM_GREEN
		;
	}
	if ((sawtooth) == (dc_blueA * arr / 100)) {
		TURN_OFF_PWM_BLUE
		;
	}
	if (sawtooth % dc_d1_red == 0) {
		TURN_OFF_D1_RED
		;
	}
	if (sawtooth % dc_d1_blue == 0) {
		TURN_OFF_D1_BLUE
		;
	}
	if (sawtooth % 100 == 0) {
		if (dc_d1_red != 0) {
			TURN_ON_D1_RED
			;
		}
		if (dc_d1_red != 0) {
			TURN_ON_D1_BLUE
						;
		}
	}
	sawtooth++;

	if ((sawtooth) == arr) {
		sawtooth = 0;
		if (dc_blueA != 0) {
			TURN_ON_PWM_BLUE
			;
		}
		if (dc_greenA != 0) {
			TURN_ON_PWM_GREEN
			;
		}
		if (dc_redA != 0) {
			TURN_ON_PWM_RED
			;
		}

	}
}

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
