/* USER CODE BEGIN Header */
#include "function.h"

/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint8_t flag10ms = 0;
uint8_t stateA=redA;
uint8_t stateB=redB;
uint16_t compt=0;
uint16_t sawtooth=0;
uint16_t dc_redA=0;uint16_t dc_greenA=0;uint16_t dc_blueA=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim4);									//Start timer for interruption

  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);

  uint16_t dc_redB=0;uint16_t dc_greenB=0;uint16_t dc_blueB=0;
  uint16_t ifsredA=0;uint16_t ifsgreenA=0;uint16_t ifsblueA=0;
  uint16_t arr=0;

  uint8_t shortpressA=FALSE;
  uint8_t longpressA=FALSE;

  uint8_t shortpressB=FALSE;
  uint8_t longpressB=FALSE;
  HAL_GPIO_WritePin(GPIOC, PC3_Pin|PC4_Pin|PC5_Pin, GPIO_PIN_RESET);
  TIM4->ARR=1000;


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  blank_sevenseg();

  while(1)
  {
	  if(1)
	  {
		  HAL_GPIO_WritePin(SEG_A_GPIO_Port, SEG_A_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(SEG_B_GPIO_Port, SEG_B_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(SEG_C_GPIO_Port, SEG_C_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(SEG_D_GPIO_Port, SEG_D_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(SEG_E_GPIO_Port, SEG_E_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(SEG_F_GPIO_Port, SEG_F_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(SEG_G_GPIO_Port, SEG_G_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(SEG_DP_GPIO_Port, SEG_DP_Pin, GPIO_PIN_SET);
		  	HAL_GPIO_WritePin(DIGIT1_GPIO_Port, DIGIT1_Pin, GPIO_PIN_SET);

/*********************************************************************Channel A*********************************************************************/
		 /* switch(stateA)
		  {
		  case redA:
			  affichageState('r', ifsredA,DELAI,0,0);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsredA=0;
				  setlight(ifsredA, redA,CHANNELA);
				  longpressA=FALSE;
			  }
			  rotate_encA(&ifsredA,redA);
			  break;

		  case greenA:
			  affichageState('g', ifsgreenA,DELAI,0,0);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsgreenA=0;
				  setlight(ifsgreenA, greenA,CHANNELA);
				  longpressA=FALSE;
			  }
			  rotate_encA(&ifsgreenA,greenA);
			  break;

		  case blueA:

			  affichageState('b', ifsblueA,DELAI,0,0);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsblueA=0;
				  setlight(ifsblueA, blueA,CHANNELA);
				  longpressA=FALSE;
			  }
			  rotate_encA(&ifsblueA,blueA);
			  break;

		  case dcredA:
			  if(compt<1000)
			  {
				  compt++;
				  affichageChar("duty", DELAI, 0,0);
			  }
			  affichageState('r', dc_redA,DELAI,0,0); HAL_GPIO_WritePin(SEG_DP_GPIO_Port, SEG_DP_Pin, GPIO_PIN_SET);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  dc_redA=0;
				  longpressA=FALSE;
			  }
			  rotate_encA(&dc_redA,21);
			  break;

		  case dcgreenA:
			  if(compt<1000)
			  {
				  compt++;
				  affichageChar("duty", DELAI, 0,0);
			  }
			  affichageState('g', dc_greenA,DELAI,0,0); HAL_GPIO_WritePin(SEG_DP_GPIO_Port, SEG_DP_Pin, GPIO_PIN_SET);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  dc_greenA=0;
				  longpressA=FALSE;
			  }
			  rotate_encA(&dc_greenA,21);
			  break;

		  case dcblueA:
			  if(compt<1000)
			  {
				  compt++;
				  affichageChar("duty", DELAI, 0,0);
			  }
			  affichageState('b', dc_blueA,DELAI,0,0); HAL_GPIO_WritePin(SEG_DP_GPIO_Port, SEG_DP_Pin, GPIO_PIN_SET);
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  dc_blueA=0;
				  longpressA=FALSE;
			  }
			  rotate_encA(&dc_blueA,21);
			  break;

		  case frequencyA:
			  if(compt<1000)
			  {
				  compt++;
				  affichageChar("freq", DELAI, 0,0);
			  }

			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  TIM4->ARR=1000;
				  longpressA=FALSE;
			  }
			  rotate_encA(&arr,ROTATE_FREQ);
			  affichageDig(TIM4->ARR,0,0);

			  break;

		  case rainbowA:
			  affichageState('b', 555,DELAI,0,0);
			  frainbowA();
			  if(longpressA==TRUE && HAL_GPIO_ReadPin(ROT_SW_2_GPIO_Port, ROT_SW_2_Pin)==TRUE)
			  {
				  ifsgreenA=0;ifsredA=0;ifsblueA=0;dc_redA=0;dc_greenA=0;dc_blueA=0;
				  setlight(ifsblueA, blueA,CHANNELA);setlight(ifsredA, redA,CHANNELA);setlight(ifsgreenA, greenA,CHANNELA);
				  longpressA=FALSE;
				  stateA=redA;
			  }
			  break;
		  }
		  is_push(&shortpressA, &longpressA, &stateA,CHANNELA);


/*********************************************************************Channel B*********************************************************************/
/*
		  switch(stateB)
		  {
		  case redB:
			  affichageState('r', dc_redB,DELAI,1,0);
			  if(longpressB==TRUE && HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)==TRUE)
			  {
				  dc_redB=0;
				  setlight(dc_redB, redB,CHANNELB);
				  longpressB=FALSE;
			  }
			  rotate_encB(&dc_redB,redB);
			  HAL_GPIO_WritePin(DIAL_B_GPIO_Port, DIAL_B_Pin, GPIO_PIN_SET);
			  HAL_GPIO_WritePin(DIAL_R_GPIO_Port, DIAL_R_Pin, GPIO_PIN_RESET);
			  HAL_GPIO_WritePin(DIAL_G_GPIO_Port, DIAL_G_Pin, GPIO_PIN_SET);
			  break;

		  case greenB:

			  affichageState('G', dc_greenB,DELAI,1,0);
			  if(longpressB==TRUE && HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)==TRUE)
			  {
				  dc_greenB=0;
				  setlight(dc_greenB, greenB,CHANNELB);
				  longpressB=FALSE;
			  }
			  rotate_encB(&dc_greenB,greenB);
			  HAL_GPIO_WritePin(DIAL_R_GPIO_Port, DIAL_R_Pin, GPIO_PIN_SET);
			  HAL_GPIO_WritePin(DIAL_G_GPIO_Port, DIAL_G_Pin, GPIO_PIN_RESET);
			  break;

		  case blueB:
			  affichageState('b', dc_blueB,DELAI,1,0);
			  if(longpressB==TRUE && HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)==TRUE)
			  {
				  dc_blueB=0;
				  setlight(dc_blueB, blueB,CHANNELB);
				  longpressB=FALSE;
			  }
			  rotate_encB(&dc_blueB,blueB);
			  HAL_GPIO_WritePin(DIAL_B_GPIO_Port, DIAL_B_Pin, GPIO_PIN_RESET);
			  HAL_GPIO_WritePin(DIAL_G_GPIO_Port, DIAL_G_Pin, GPIO_PIN_SET);
			  break;

		  case rainbowB:
			  affichageState('w', 555,DELAI,1,0);
			  frainbowB();
			  if(longpressB==TRUE && HAL_GPIO_ReadPin(ROT_SW_1_GPIO_Port, ROT_SW_1_Pin)==TRUE)
			  {
				  dc_blueB=0;dc_redB=0;dc_greenB=0;
				  setlight(dc_blueB, blueB,CHANNELB);setlight(dc_redB, redB,CHANNELB);setlight(dc_greenB, greenB,CHANNELB);
				  longpressB=FALSE;
				  stateB=redB;
			  }
			  break;
		  }
		  is_push(&shortpressB, &longpressB, &stateB,CHANNELB);

		  flag10ms=0;*/
	  }
  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV4;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	flag10ms=1;//Synchronization flag, get high every 1ms
	sawtooth++;
	if(sawtooth>dc_redA)
	{
		HAL_GPIO_WritePin(GPIOC, PC3_Pin, GPIO_PIN_RESET);
	}
	if(sawtooth>dc_greenA)
	{
		HAL_GPIO_WritePin(GPIOC, PC4_Pin, GPIO_PIN_RESET);
	}
	if(sawtooth>dc_blueA)
	{
		HAL_GPIO_WritePin(GPIOC, PC5_Pin, GPIO_PIN_RESET);
	}
	if(sawtooth==TIM4->ARR)
	{
		sawtooth=0;
		if(dc_blueA>0)
		{
			HAL_GPIO_WritePin(GPIOC, PC5_Pin, GPIO_PIN_SET);
		}
		if(dc_greenA>0)
		{
			HAL_GPIO_WritePin(GPIOC, PC4_Pin, GPIO_PIN_SET);
		}
		if(dc_redA>0)
		{
			HAL_GPIO_WritePin(GPIOC, PC3_Pin, GPIO_PIN_SET);
		}
	}
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
