/*
 * function.h
 *
 *  Created on: Oct 10, 2022
 *      Author: simon.degres
 */

#include <stdio.h>
#ifndef INC_FUNCTION_H_		/* This is an "include guard" */
							/* prevents the file from being included twice. */
							/* Including a header file twice causes all kinds */
							/* of interesting problems.*/
#define INC_FUNCTION_H_

enum{redB,greenB,blueB,rainbowB};

enum{redA,greenA,blueA,duty_cycleA,frequencyA,rainbowA};

enum{blanc,bleu,vert,rouge,violet, jaune, cyan,};

#define TRUE 1
#define FALSE 0

#define CHANNELA 0
#define CHANNELB 1

#define DELAI 1

#define CURRENT_INCREMENT 2 		//Incrementation of the current in mA when turning the encoder
#define MAX_CURRENT 500				//Max current through the transistor in mA (Up to 5A)

#define CLOCKWISE 0

#define DISPLAY_OFFSET(display_number)	(64 - (8*(display_number))) - 1	//Allow to choose one 7seg

									//Put a digit on a 7seg
#define DIGIT_PUSH(flux_offset, digit) {			\
	flux[(flux_offset)-0] = 0;						\
	flux[(flux_offset)-1] = DIGITS[(digit)*7+0];	\
	flux[(flux_offset)-2] = DIGITS[(digit)*7+1];	\
	flux[(flux_offset)-3] = DIGITS[(digit)*7+2];	\
	flux[(flux_offset)-4] = DIGITS[(digit)*7+3];	\
	flux[(flux_offset)-5] = DIGITS[(digit)*7+4];	\
	flux[(flux_offset)-6] = DIGITS[(digit)*7+5];	\
	flux[(flux_offset)-7] = DIGITS[(digit)*7+6];	\
}

									//Turn off every segment of a 7seg
#define DIGIT_PUSH_BLANK(flux_offset) {	\
	flux[(flux_offset)-0] = flux[(flux_offset)-1] = flux[(flux_offset)-2] = flux[(flux_offset)-3] =		\
	flux[(flux_offset)-4] = flux[(flux_offset)-5] = flux[(flux_offset)-6] = flux[(flux_offset)-7] =	0;	\
}

extern uint8_t flag10ms;
extern  uint8_t stateA;
extern  uint8_t stateB;

void printchar(int chara,uint16_t Pin);
void affichageChar(char * word,int delai, int position, int appel);
void printFigures(uint16_t number,uint16_t Pin, int leading_zero);
void affichageState(char letterstate, int number,int delai,int position,int appel);

void rainbow(void);

void blank_sevenseg(void);

void getADC(uint16_t *current_meas, uint16_t *voltage, uint16_t *voltage_5v, uint16_t *temp_meas);
void convert_dig_to_analog(uint16_t voltage,uint16_t current_sense,float *power,uint16_t *temp_meas, int16_t *temperature,double *voltage_disp,double *current_disp);

void setlight(uint16_t percent,uint8_t channel_timer, uint8_t channel);

void rotate_enc(uint16_t *alphaa,uint8_t channel_timer, uint8_t channel);
void is_push(uint8_t *shortpress,uint8_t *longpress, uint8_t *state, uint8_t channel);

#endif /* INC_BSP_FR_H_ */
