/*
 * function.h
 *
 *  Created on: Oct 10, 2022
 *      Author: simon.degres
 */

#include <stdio.h>
#ifndef INC_FUNCTION_H_		/* This is an "include guard" */
							/* prevents the file from being included twice. */
							/* Including a header file twice causes all kinds */
							/* of interesting problems.*/
#define INC_FUNCTION_H_

enum{redB,greenB,blueB,rainbowB};

enum{redA,greenA,blueA,dcredA,dcgreenA,dcblueA,frequencyA,rainbowA};

enum{blanc,bleu,vert,rouge,violet, jaune, cyan,};

#define TRUE 1
#define FALSE 0

#define CHANNELA 0
#define CHANNELB 1

#define DELAI 1

#define ROTATE_FREQ 20

#define CURRENT_INCREMENT 2 		//Incrementation of the current in mA when turning the encoder
#define MAX_CURRENT 500				//Max current through the transistor in mA (Up to 5A)

#define CLOCKWISE 0

extern uint8_t flag10ms;
extern  uint8_t stateA;
extern  uint8_t stateB;
extern uint16_t compt;

void printchar(int chara,uint16_t Pin);
void affichageChar(char * word,int delai, int position, int appel);
void affichageDig(int position_compteur,int position,int appel);
void printFigures(uint16_t number,uint16_t Pin, int leading_zero);
void affichageState(char letterstate, int number,int delai,int position,int appel);

void frainbowB(void);
void frainbowA(void);

void blank_sevenseg(void);

void getADC(uint16_t *current_meas, uint16_t *voltage, uint16_t *voltage_5v, uint16_t *temp_meas);
void convert_dig_to_analog(uint16_t voltage,uint16_t current_sense,float *power,uint16_t *temp_meas, int16_t *temperature,double *voltage_disp,double *current_disp);

void setlight(uint16_t percent,uint8_t channel_timer, uint8_t channel);

void rotate_encA(uint16_t *alphaa,uint8_t channel_timer);
void rotate_encB(uint16_t *alphaa,uint8_t channel_timer);
void is_push(uint8_t *shortpress,uint8_t *longpress, uint8_t *state, uint8_t channel);

#endif /* INC_BSP_FR_H_ */
