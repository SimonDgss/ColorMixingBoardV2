/*
 * function.h
 *
 *  Created on: Oct 10, 2022
 *      Author: simon.degres
 */

#include <stdio.h>
#ifndef INC_FUNCTION_H_		/* This is an "include guard" */
/* prevents the file from being included twice. */
/* Including a header file twice causes all kinds */
/* of interesting problems.*/
#define INC_FUNCTION_H_

enum {
	redB, greenB, blueB, rainbowB
};

enum {
	maxifsA, frequencyA, dcredA, dcgreenA, dcblueA/*,rainbowA*/
};

enum {
	white, blue, green, red, purple, yellow, cyan, purple2
};

#define TRUE 1
#define FALSE 0

#define CHANNELA 0
#define CHANNELB 1

#define DELAY 1

#define ROTATE_FREQ 20
#define ROTATE_IFS 21

#define INCREMENT 1 		//Incrementation of the current in mA when turning the encoder
#define MAX_CURRENT 500				//Max current through the transistor in mA (Up to 5A)

#define CLOCKWISE 0

#define TIME_STATE 2000

#define TURN_ON_D1_GREEN HAL_GPIO_WritePin(GPIOA, DIAL_G_Pin, GPIO_PIN_RESET);	//Define to give the right pin the right name
#define TURN_ON_D1_BLUE HAL_GPIO_WritePin(GPIOA, DIAL_B_Pin, GPIO_PIN_RESET);
#define TURN_ON_D1_RED HAL_GPIO_WritePin(GPIOA, DIAL_R_Pin, GPIO_PIN_RESET);

#define TURN_OFF_D1_GREEN HAL_GPIO_WritePin(GPIOA, DIAL_G_Pin, GPIO_PIN_SET);
#define TURN_OFF_D1_BLUE HAL_GPIO_WritePin(GPIOA, DIAL_B_Pin, GPIO_PIN_SET);
#define TURN_OFF_D1_RED HAL_GPIO_WritePin(GPIOA, DIAL_R_Pin, GPIO_PIN_SET);

extern uint8_t flag1ms;
extern uint8_t stateA;
extern uint8_t stateB;
extern uint16_t compt;
extern uint16_t max_ifsA;
extern uint16_t psc;
extern uint16_t arr;
extern uint8_t daugtherboardA;
extern uint8_t daugtherboardB;

void printchar(uint16_t chara, uint16_t Pin);
void displayChar(char *word, uint8_t delai, uint8_t position, uint8_t call);
void displayDig(uint16_t position_compteur, uint8_t position, uint8_t call);
void printFigures(uint8_t number, uint16_t Pin, uint8_t leading_zero);
void displayState(char letterstate, uint8_t number, uint8_t delai,
		uint8_t position, uint8_t call);
void dispfreq(uint16_t arr);

void frainbowB(void);
void frainbowA(void);

void blank_sevenseg(void);

void getADC(uint16_t *maxA, uint16_t *maxB);
void convert_dig_to_analog(uint16_t *maxA, uint16_t *maxB,
		uint8_t *daugtherboardA, uint8_t *daugtherboardB);

void setlight(uint16_t percent, uint8_t channel_timer, uint8_t channel);

void rotate_encA(uint16_t *alphaa, uint8_t channel_timer, uint8_t clockwise);
void rotate_encB(uint16_t *alphaa, uint8_t channel_timer);
void is_push(uint8_t *shortpress, uint8_t *longpress, uint8_t *state,
		uint8_t channel);

#endif /* INC_BSP_FR_H_ */
